// conversation create (iki kullanıcıyla)
async function createConversation(uids){
  // uids: array of user uids (ör. [currentUser.uid, otherUid])
  const convRef = await addDoc(collection(db, 'conversations'), {
    participants: uids,
    createdAt: serverTimestamp(),
    lastMessageAt: serverTimestamp()
  });
  return convRef.id;
}

// send message
async function sendMessage(convId, text, attachments=[]){
  if(!currentUser) throw new Error('Not signed in');
  const msgRef = await addDoc(collection(db, 'conversations', convId, 'messages'), {
    senderUid: currentUser.uid,
    senderName: currentUser.displayName || null,
    text,
    attachments,
    createdAt: serverTimestamp()
  });
  // update conversation lastMessageAt (optional)
  await updateDoc(doc(db, 'conversations', convId), { lastMessageText: text, lastMessageAt: serverTimestamp() });
  return msgRef.id;
}

// realtime listen messages
function listenMessages(convId, onMessage){
  const q = query(collection(db, 'conversations', convId, 'messages'), orderBy('createdAt', 'asc'));
  const unsub = onSnapshot(q, snap => {
    snap.docChanges().forEach(ch => {
      if(ch.type === 'added'){
        onMessage({ id: ch.doc.id, ...ch.doc.data() });
      }
    });
  });
  return unsub;
}