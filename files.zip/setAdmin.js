/**
 * Usage:
 *   node setAdmin.js user@example.com
 *
 * Requirements:
 *  - serviceAccountKey.json (download from Firebase Console > Project Settings > Service accounts)
 *  - npm install firebase-admin
 *
 * This script sets custom claim {admin: true} on given user's uid.
 */
const admin = require('firebase-admin');
const fs = require('fs');
const path = require('path');

const keyPath = path.resolve(__dirname, 'serviceAccountKey.json');
if (!fs.existsSync(keyPath)) {
  console.error('serviceAccountKey.json bulunamadı. Firebase Console -> Project Settings -> Service accounts -> Generate new private key.');
  process.exit(1);
}

admin.initializeApp({
  credential: admin.credential.cert(require(keyPath))
});

async function setAdmin(email) {
  try {
    const user = await admin.auth().getUserByEmail(email);
    await admin.auth().setCustomUserClaims(user.uid, { admin: true });
    await admin.firestore().collection('admins').doc(user.uid).set({
      email: user.email,
      assignedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    console.log(`Admin hakları verildi: ${email}`);
  } catch (err) {
    console.error('Hata:', err);
  }
}

const email = process.argv[2];
if (!email) {
  console.error('Kullanım: node setAdmin.js user@example.com');
  process.exit(1);
}
setAdmin(email).then(() => process.exit(0));