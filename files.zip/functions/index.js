// Node.js Cloud Function (Firebase Functions)
const functions = require('firebase-functions');
const admin = require('firebase-admin');

admin.initializeApp();

// Set via: firebase functions:config:set admin.secret="YOUR_LONG_SECRET"
const OWNER_SECRET = functions.config().admin && functions.config().admin.secret ? functions.config().admin.secret : null;

exports.manageAdmin = functions.https.onRequest(async (req, res) => {
  try {
    if (req.method !== 'POST') return res.status(405).send('POST required');
    const { secret, email, action } = req.body || {};
    if (!OWNER_SECRET || secret !== OWNER_SECRET) return res.status(403).send('Forbidden');
    if (!email || !action) return res.status(400).send('Missing email or action');

    const user = await admin.auth().getUserByEmail(email);
    if (!user) return res.status(404).send('User not found');

    if (action === 'set') {
      await admin.auth().setCustomUserClaims(user.uid, { admin: true });
      await admin.firestore().collection('admins').doc(user.uid).set({ email: user.email, assignedAt: admin.firestore.FieldValue.serverTimestamp() });
      return res.status(200).send(`Admin set for ${email}`);
    } else if (action === 'unset') {
      await admin.auth().setCustomUserClaims(user.uid, { admin: false });
      await admin.firestore().collection('admins').doc(user.uid).delete();
      return res.status(200).send(`Admin unset for ${email}`);
    } else {
      return res.status(400).send('Unknown action');
    }
  } catch (err) {
    console.error(err);
    return res.status(500).send(err.message || err);
  }
});